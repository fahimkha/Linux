# Installing Node Using the Node Version Manager

1. curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.3/install.sh | bash

2. source ~/.bashrc

3. nvm list-remote

4. nvm install v18.18.2

5. node -v

You can install multiple version then use specific version *nvm use v18.10.0*

Removing Node.js
1. sudo apt remove nodejs
2. sudo apt purge nodejs
3. nvm current
4. nvm uninstall node_version







[Referance](https://www.digitalocean.com/community/tutorials/how-to-install-node-js-on-ubuntu-20-04)